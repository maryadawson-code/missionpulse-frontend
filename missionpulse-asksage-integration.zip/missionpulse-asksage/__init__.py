"""
================================================================================
MISSIONPULSE - ASKSAGE INTEGRATION PACKAGE
================================================================================
FedRAMP High / IL5 compliant AI integration layer with intelligent model
routing for cost optimization.

Author: Mission Meets Tech
Version: 2.0.0
================================================================================
"""

__version__ = "2.0.0"
__author__ = "Mission Meets Tech"

# Core client
from .asksage_client import (
    AskSageClient,
    AskSageConfig,
    AskSageEnvironment,
    AskSageResponse,
    get_asksage_client,
    create_asksage_client
)

# Query classification & routing
from .query_classifier import (
    QueryClassifier,
    ClassificationResult,
    ComplexityLevel,
    get_classifier
)

# Model configuration
from .model_config import (
    MODEL_REGISTRY,
    AGENT_MODEL_DEFAULTS,
    ModelDefinition,
    ModelTier,
    ModelCapability,
    get_model,
    get_models_by_tier,
    get_cui_authorized_models,
    get_cheapest_capable_model,
    estimate_query_cost
)

# Base agent
from .base_agent_v2 import (
    BaseAgent,
    AgentConfig,
    AgentResponse,
    AgentType,
    ConfidenceLevel,
    Citation
)

__all__ = [
    # Version
    "__version__",
    
    # Client
    "AskSageClient",
    "AskSageConfig", 
    "AskSageEnvironment",
    "AskSageResponse",
    "get_asksage_client",
    "create_asksage_client",
    
    # Classification
    "QueryClassifier",
    "ClassificationResult",
    "ComplexityLevel",
    "get_classifier",
    
    # Models
    "MODEL_REGISTRY",
    "AGENT_MODEL_DEFAULTS",
    "ModelDefinition",
    "ModelTier",
    "ModelCapability",
    "get_model",
    "get_models_by_tier",
    "get_cui_authorized_models",
    "get_cheapest_capable_model",
    "estimate_query_cost",
    
    # Agents
    "BaseAgent",
    "AgentConfig",
    "AgentResponse",
    "AgentType",
    "ConfidenceLevel",
    "Citation"
]
