"""
================================================================================
MISSIONPULSE - ASKSAGE INTEGRATION TEST
================================================================================
Run this script to verify AskSage integration is working correctly.

Usage:
    python test_asksage_integration.py

Prerequisites:
    1. Copy .env.example to .env
    2. Fill in your AskSage credentials
    3. pip install -r requirements.txt

Author: Mission Meets Tech
================================================================================
"""

import asyncio
import os
import sys
from datetime import datetime

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from asksage_client import (
    AskSageClient,
    AskSageConfig,
    AskSageEnvironment,
    get_asksage_client
)
from query_classifier import QueryClassifier, get_classifier
from model_config import MODEL_REGISTRY, get_model


def print_header(text: str):
    """Print formatted header."""
    print(f"\n{'='*60}")
    print(f"  {text}")
    print(f"{'='*60}\n")


def print_success(text: str):
    """Print success message."""
    print(f"✅ {text}")


def print_error(text: str):
    """Print error message."""
    print(f"❌ {text}")


def print_info(text: str):
    """Print info message."""
    print(f"ℹ️  {text}")


async def test_environment():
    """Test environment configuration."""
    print_header("TEST 1: Environment Configuration")
    
    api_key = os.getenv("ASKSAGE_API_KEY")
    email = os.getenv("ASKSAGE_EMAIL")
    environment = os.getenv("ASKSAGE_ENVIRONMENT", "commercial")
    
    if not api_key:
        print_error("ASKSAGE_API_KEY not set in environment")
        return False
    else:
        print_success(f"API Key: {'*' * 20}{api_key[-4:]}")
    
    if not email:
        print_error("ASKSAGE_EMAIL not set in environment")
        return False
    else:
        print_success(f"Email: {email}")
    
    print_success(f"Environment: {environment}")
    
    return True


async def test_classifier():
    """Test query classifier."""
    print_header("TEST 2: Query Classifier (Smart Routing)")
    
    classifier = get_classifier()
    
    test_cases = [
        # (query, agent_type, expected_complexity)
        ("Hi there!", "capture", "simple"),
        ("What's our win probability?", "capture", "moderate"),
        ("Analyze the PWS and identify all FAR/DFARS requirements for CMMC Level 2 compliance", "compliance", "complex"),
        ("Should we go or no-go on this $50M IDIQ with CUI requirements?", "pricing", "critical"),
    ]
    
    all_passed = True
    
    for query, agent_type, expected in test_cases:
        result = classifier.classify(query, agent_type)
        status = "✅" if expected in result.complexity_level.value else "⚠️"
        print(f"{status} Query: '{query[:50]}...'")
        print(f"   Score: {result.complexity_score}/100 → {result.complexity_level.value}")
        print(f"   Model: {result.recommended_model} ({result.model_tier.value})")
        print(f"   CUI: {'Yes' if result.cui_detected else 'No'}")
        print()
    
    return all_passed


async def test_authentication():
    """Test AskSage authentication."""
    print_header("TEST 3: AskSage Authentication")
    
    try:
        config = AskSageConfig.from_env()
        client = AskSageClient(config)
        
        # This will trigger token fetch
        await client._ensure_token()
        
        if client._token:
            print_success(f"Token acquired successfully")
            print_info(f"Expires: {client._token.expires_at}")
            return True
        else:
            print_error("Failed to acquire token")
            return False
            
    except Exception as e:
        print_error(f"Authentication failed: {e}")
        return False


async def test_simple_query():
    """Test a simple query to AskSage."""
    print_header("TEST 4: Simple Query")
    
    try:
        client = get_asksage_client()
        
        response = await client.query(
            message="What is 2 + 2? Reply with just the number.",
            agent_type="capture",
            model="gpt-4o-mini"  # Force cheapest model for test
        )
        
        print_success(f"Response received!")
        print_info(f"Content: {response.content[:100]}...")
        print_info(f"Model: {response.model}")
        print_info(f"Tokens: {response.input_tokens} in / {response.output_tokens} out")
        print_info(f"Cost: ${response.estimated_cost:.6f}")
        print_info(f"Time: {response.response_time_ms}ms")
        
        return True
        
    except Exception as e:
        print_error(f"Query failed: {e}")
        return False


async def test_smart_routing():
    """Test smart model routing."""
    print_header("TEST 5: Smart Model Routing")
    
    try:
        client = get_asksage_client()
        
        # Simple query - should route to economy tier
        response1 = await client.query(
            message="What does FAR stand for?",
            agent_type="compliance"
        )
        
        print_success(f"Simple query routed to: {response1.model}")
        if response1.classification:
            print_info(f"Classification: {response1.classification.complexity_level.value}")
            print_info(f"Reason: {response1.classification.routing_reason}")
        
        # Complex query - should route to higher tier
        response2 = await client.query(
            message="Analyze the competitive landscape for a DHA EHR modernization contract. Consider incumbent advantages, our discriminators, and recommend a go/no-go decision.",
            agent_type="capture"
        )
        
        print_success(f"Complex query routed to: {response2.model}")
        if response2.classification:
            print_info(f"Classification: {response2.classification.complexity_level.value}")
            print_info(f"Reason: {response2.classification.routing_reason}")
        
        return True
        
    except Exception as e:
        print_error(f"Smart routing test failed: {e}")
        return False


async def test_model_registry():
    """Test model registry configuration."""
    print_header("TEST 6: Model Registry")
    
    print_info(f"Registered models: {len(MODEL_REGISTRY)}")
    
    for model_id, model in MODEL_REGISTRY.items():
        cui_badge = "🔒" if model.cui_authorized else "  "
        print(f"  {cui_badge} {model_id}: {model.tier.value} tier, ${model.input_cost_per_1k}/1K in")
    
    print()
    print_success("Model registry loaded successfully")
    
    return True


async def main():
    """Run all tests."""
    print("\n")
    print("🚀 MISSIONPULSE ASKSAGE INTEGRATION TEST")
    print("=" * 60)
    print(f"Time: {datetime.now().isoformat()}")
    print("=" * 60)
    
    results = []
    
    # Run tests
    results.append(("Environment", await test_environment()))
    results.append(("Classifier", await test_classifier()))
    results.append(("Model Registry", await test_model_registry()))
    
    # Only run API tests if environment is configured
    if results[0][1]:  # Environment test passed
        results.append(("Authentication", await test_authentication()))
        
        if results[-1][1]:  # Auth test passed
            results.append(("Simple Query", await test_simple_query()))
            results.append(("Smart Routing", await test_smart_routing()))
    
    # Summary
    print_header("TEST SUMMARY")
    
    passed = 0
    failed = 0
    
    for name, result in results:
        if result:
            print_success(f"{name}")
            passed += 1
        else:
            print_error(f"{name}")
            failed += 1
    
    print()
    print(f"Passed: {passed}/{len(results)}")
    
    if failed == 0:
        print("\n🎉 All tests passed! AskSage integration is ready.")
    else:
        print(f"\n⚠️  {failed} test(s) failed. Check configuration and try again.")
    
    return failed == 0


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
